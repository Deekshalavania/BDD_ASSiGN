package LoginPageFactory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.HotelBookingRegistration;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLogin {

private WebDriver driver;
private HotelBookingRegistration regis;
JavascriptExecutor js = (JavascriptExecutor)driver;

@Given("^User is on Hotel Booking Login Application$")
public void user_is_on_Hotel_Booking_Login_Application() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\chromeexe-master\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	regis = new HotelBookingRegistration(driver);
	driver.get("file:///D:/Users/DLAVANIA/Desktop/Deeksha/Module%203/login.html");
	
}

@Then("^check the title of the page$")
public void check_the_title_of_the_page() throws Throwable {
String title=driver.getTitle();
if(title.contentEquals("")) System.out.println("***************TITLE MATCHED*************");
else System.out.println("*****************TITLE DO NOT MATCHED*********************");
}

@When("^User enters all valid data$")
public void user_enters_all_valid_data() throws Throwable {
	regis.setPffname("capgemini");Thread.sleep(1000);
	regis.setPffpswrd("capg1234");Thread.sleep(1000);

 
}

@Then("^navigate to Hotel Booking page$")
public void navigate_to_Hotel_Booking_page() throws Throwable {
	driver.navigate().to("file:///D:/Users/DLAVANIA/Desktop/Deeksha/Module%203/hotelbooking.html");
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	Thread.sleep(1000);
	driver.close();
}

@When("^user leaves Username blank and clicks the button$")
public void user_leaves_Username_blank_and_clicks_the_button() throws Throwable {
	regis.setPffname(""); Thread.sleep(1000);
	regis.setPffpswrd("capg1234");
	Thread.sleep(1000);
	regis.setPffbutton();
}
@Then("^display ualert message$")
public void display_ualert_message() throws Throwable {
String userAlert=driver.findElement(By.id("userErrMsg")).getText();
Thread.sleep(1000);
System.out.println("**************"+ userAlert);
driver.close();
}



@When("^User leaves Password blank and Clicks the button$")
public void user_leaves_Password_blank_and_Clicks_the_button() throws Throwable {
	regis.setPffname("capgemini"); Thread.sleep(1000);
	regis.setPffpswrd("");
	Thread.sleep(1000);
	regis.setPffbutton();

}


@Then("^display palert message$")
public void display_palert_message() throws Throwable {
	String pwdAlert=driver.findElement(By.id("pwdErrMsg")).getText();
	Thread.sleep(1000);
	System.out.println("**************"+ pwdAlert);
	driver.close();

}
@When("^User enter wrong userName and Password and Clicks the button$")
public void user_enter_wrong_userName_and_Password_and_Clicks_the_button() throws Throwable {
	regis.setPffname("Capgeminiiiiii");
	Thread.sleep(1000);
	regis.setPffpswrd("fughu");
	Thread.sleep(1000);
	regis.setPffbutton();
   
	
}

@Then("^display alert message$")
public void display_alert_message() throws Throwable {
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
    System.out.println("******" + alertMessage);
    driver.close();
}
}