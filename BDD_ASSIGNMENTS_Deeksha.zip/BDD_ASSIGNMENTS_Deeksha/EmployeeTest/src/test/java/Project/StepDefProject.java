package Project;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBeanLogin.LoginBean;
import PageBeanProject.ProjectBean;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefProject {
	WebDriver driver;
	ProjectBean pro;
	
	@Given("^user is on Project Page$")
	public void user_is_on_Project_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\chromeexe-master\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		pro = new ProjectBean(driver);
		driver.get("file:///D:/Users/DLAVANIA/Downloads/TeamProject-master/project.html");
	}

	@Then("^check the title$")
	public void check_the_title() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Project page")) System.out.println("***************TITLE MATCHED*************");
		else System.out.println("*****************TITLE DO NOT MATCHED*********************");
	}

	@When("^User enter all valid data$")
	public void user_enter_all_valid_data() throws Throwable {
	  pro.setPffname("Sita");
	}

	@Then("^navigate to registered Page$")
	public void navigate_to_registered_Page() throws Throwable {
		driver.navigate().to("file:///D:/Users/DLAVANIA/Downloads/TeamProject-master/registered.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^User leaves employeeName blank$")
	public void user_leaves_employeeName_blank() throws Throwable {
		  pro.setPffname("");
		  pro.setPffregister();
	}

	@Then("^display nameAlert msg$")
	public void display_nameAlert_msg() throws Throwable {
		
			Alert alert=driver.switchTo().alert();
			assertEquals("Please enter Employee id", alert.getText());
			driver.quit(); 
		 

	}



}
