package FeatureReset;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
WebDriver driver;
@Given("^Open the Firefox and launch the application$")
public void open_the_Firefox_and_launch_the_application() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("file:///D:/Users/DLAVANIA/Desktop/Deeksha/Module%203/WorkingWithForms.html");
   // throw new PendingException();
}

@When("^Enter the Username and Password$")
public void enter_the_Username_and_Password() throws Throwable {
	driver.findElement(By.id("txtUserName")).sendKeys("DLAVANIA");
	try {
		Thread.sleep(10000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	//Find password textbox and enter value
	driver.findElement(By.name("txtPwd")).sendKeys("afsfdf");
	try {
		Thread.sleep(10000);
	} catch (InterruptedException e) {
		
		e.printStackTrace();
	}
	
    //throw new PendingException();
}

@Then("^Reset the credential$")
public void reset_the_credential() throws Throwable {
	driver.findElement(By.name("reset")).click();

    //throw new PendingException();
}

}
