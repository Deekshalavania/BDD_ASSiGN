package WebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class WorkingWithForms {

	public static void main(String[] args) {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/Users/DLAVANIA/Desktop/Deeksha/Module%203/WorkingWithForms.html");
	
		driver.findElement(By.id("txtUserName")).sendKeys("DLAVANIA");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}
		//Find password textbox and enter value
		driver.findElement(By.name("txtPwd")).sendKeys("1234");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		driver.findElement(By.className("Format")).sendKeys("1234");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		//find firstName textBox and enter value
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Deeksha");
		//find LasttName textBox and enter value
		driver.findElement(By.name("txtLN")).sendKeys("Lavania");
		//find gender radio button and enter value
		driver.findElement(By.xpath(".//*[@id='rbMale']")).sendKeys("Female");
		//find DOB textBox and enter value
		driver.findElement(By.name("DtOB")).sendKeys("20/12/1983");
		//find email textBox and enter value
		driver.findElement(By.name("Email")).sendKeys("dlavania00@gmail.com");
		//find address textBox and enter value
		driver.findElement(By.name("Address")).sendKeys("Maholi Nagar");
		//find city textBox and enter value
		//Selenium can not work with dropDrown menu so,we use select class for dropdown only
		driver.findElement(By.name("txtLN")).sendKeys("Pandit");
		Select dropCity=new Select(driver.findElement(By.name("City")));

		//dropCity.selectByVisibleText("Mumbai");
		dropCity.selectByIndex(1);
		//dropCity.selectByIndex(2);

		//driver.findElement((By.xpath(".//*[@id='txtPhone']")).sendKeys("9897857709");
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9897026057");
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		driver.findElement(By.cssSelector("input[value='Music']")).click();
		driver.findElement(By.name("reset")).click();
		

	}

}
