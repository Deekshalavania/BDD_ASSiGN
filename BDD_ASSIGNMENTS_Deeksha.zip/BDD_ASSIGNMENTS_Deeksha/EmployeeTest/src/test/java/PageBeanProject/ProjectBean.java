package PageBeanProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProjectBean {

	WebDriver driver;
	
	@FindBy(name="fn")
	@CacheLookup
	WebElement pffname;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[2]/td/input[5]")
	@CacheLookup
	WebElement pffregister;

	public ProjectBean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getPfname() {
		return pffname;
	}

	public void setPffname(String sfname) {
		pffname.sendKeys(sfname);
	}

	public WebElement getPffregister() {
		return pffregister;
	}

	public void setPffregister() {
		pffregister.click();
	}
	
	
}
